MaxQuant Analysis Results - Complete Submission Example
=======================================================

Analysis Tool: MaxQuant v2.4.13.0
Analysis Date: 2026-02-01
Experiment: Human Liver Proteome Study

Raw Files Analyzed:
- sample1.raw (Technical Replicate 1)
- sample2.raw (Technical Replicate 1)
- sample3.raw (Technical Replicate 2)

Database: UniProt Human Reviewed (2024_01)

Search Parameters:
- Enzyme: Trypsin/P
- Max missed cleavages: 2
- Fixed modifications: Carbamidomethyl (C)
- Variable modifications: Oxidation (M), Acetyl (Protein N-term)
- PSM FDR: 1%
- Protein FDR: 1%
- Match between runs: Enabled

Contents of this archive:
-------------------------
1. evidence.txt - PSM-level identifications and quantifications
2. peptides.txt - Peptide-level results
3. proteinGroups.txt - Protein group results
4. parameters.txt - Analysis parameters
5. summary.txt - Run summary statistics
6. mqpar.xml - MaxQuant parameter file
7. msms.txt - MS/MS scan information
8. mzTab.mzTab - Standard format output for COMPLETE submission

For questions, contact: researcher@example.org
